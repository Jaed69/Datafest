"""Send a Git-identified source snapshot; recover and verify each completed fold.

Run with .venv/bin/python scripts/run_foundation_colab.py --model tabfm.
This owns only the newly allocated named session and always releases it.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from datafest.lineage import file_record, verify_manifest_integrity, write_json


def command(args, **kwargs):
    return subprocess.run(args,check=True,text=True,**kwargs)


def source_snapshot(destination: Path) -> str:
    """Create an unattached Git commit; preserve the user's index and branch."""
    with tempfile.TemporaryDirectory() as temp:
        env=dict(os.environ,GIT_INDEX_FILE=str(Path(temp)/"index"))
        command(["git","read-tree","HEAD"],env=env)
        paths=[str(p) for folder in ("src","tests","scripts") for p in Path(folder).rglob("*.py")]
        paths += ["pyproject.toml","uv.lock"]
        command(["git","add","--",*paths],env=env)
        tree=command(["git","write-tree"],env=env,capture_output=True).stdout.strip()
        commit=command(["git","-c","user.name=Datafest experiment","-c","user.email=datafest@localhost",
                        "commit-tree",tree,"-p","HEAD","-m","Snapshot for rolling foundation experiments"],
                        capture_output=True).stdout.strip()
    command(["git","archive","--format=tar.gz","-o",str(destination),commit,
             "src","tests","scripts","pyproject.toml","uv.lock"])
    return commit


def run(model, gpu, session, existing=False):
    root=Path("experiments/diagnostics/04_foundation")
    root.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="datafest-colab-") as temp:
        temp=Path(temp)
        commit=source_snapshot(temp/"source.tar.gz")
        import shutil
        shutil.copy2(temp/"source.tar.gz",root/"source_snapshot.tar.gz")
        write_json(root/"source_snapshot.json",{"git_commit":commit,"archive":file_record(root/"source_snapshot.tar.gz")})
        requirements=Path("experiments/diagnostics/foundation-requirements.txt")
        if not requirements.exists():
            raise RuntimeError("Missing pinned foundation-requirements.txt")
        bundle=temp/"bundle.tar.gz"
        with tarfile.open(bundle,"w:gz") as archive:
            archive.add(temp/"source.tar.gz",arcname="source.tar.gz")
            archive.add(requirements,arcname="foundation-requirements.txt")
            archive.add(root/"source_snapshot.json",arcname=str(root/"source_snapshot.json"))
            archive.add(root/"source_snapshot.tar.gz",arcname=str(root/"source_snapshot.tar.gz"))
            archive.add("data/train.csv",arcname="data/train.csv")
            if (root/model).exists():
                archive.add(root/model,arcname=str(root/model))
        created=existing
        try:
            if not existing:
                command(["colab","new","-s",session,"--gpu",gpu])
                created=True
            command(["colab","upload","-s",session,str(bundle),"/content/datafest-bundle.tar.gz"])
            setup=temp/"setup.py"
            setup.write_text('''import os, subprocess, tarfile
from pathlib import Path
def stream(cmd):
    proc=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    for line in proc.stdout: print(line,end='',flush=True)
    if proc.wait(): raise RuntimeError('Remote command failed: '+repr(cmd))
root=Path('/content/datafest')
root.mkdir(exist_ok=True)
with tarfile.open('/content/datafest-bundle.tar.gz') as tar: tar.extractall(root,filter='data')
with tarfile.open(root/'source.tar.gz') as tar: tar.extractall(root,filter='data')
stream(['python','-m','pip','install','uv'])
stream(['uv','venv','/content/datafest-env','--python','3.12','--managed-python'])
stream(['uv','pip','install','--python','/content/datafest-env/bin/python','-r',str(root/'foundation-requirements.txt')])
stream(['nvidia-smi'])
''')
            command(["colab","exec","-s",session,"--timeout","1800","-f",str(setup)])
            for month in (202609,202610,202611):
                remote=temp/f"fold_{month}.py"
                worker=temp/f"worker_{month}.py"
                worker.write_text(f'''import os, sys
from pathlib import Path
os.chdir('/content/datafest')
sys.path.insert(0,'/content/datafest/src')
from datafest.foundation import run_foundation
result=run_foundation({model!r},Path('data'),Path('experiments/diagnostics/04_foundation'),'cuda',{month})
print(result,flush=True)
''')
                remote.write_text(f'''import os, tarfile, subprocess, traceback
from pathlib import Path
os.chdir('/content/datafest')
Path('/content/datafest-worker.py').write_text({worker.read_text()!r})
try:
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MPLBACKEND='Agg')
    proc=subprocess.Popen(['/content/datafest-env/bin/python','/content/datafest-worker.py'],env=env,
                          stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    for line in proc.stdout: print(line,end='',flush=True)
    print('worker_exit_code:',proc.wait(),flush=True)
except Exception:
    traceback.print_exc()
finally:
    with tarfile.open('/content/datafest-results-{month}.tar.gz','w:gz') as tar:
        tar.add('experiments/diagnostics/04_foundation/{model}',arcname='experiments/diagnostics/04_foundation/{model}')
''')
                # Recovery is attempted even when execution reports failure.
                subprocess.run(["colab","exec","-s",session,"--timeout","3600","-f",str(remote)],check=False)
                recovered=root/f"recovered_{model}_{month}.tar.gz"
                command(["colab","download","-s",session,f"/content/datafest-results-{month}.tar.gz",str(recovered)])
                with tarfile.open(recovered) as archive:
                    archive.extractall(Path.cwd(),filter="data")
                for path in (root/model).rglob("manifest.json"):
                    errors=verify_manifest_integrity(json.loads(path.read_text()))
                    if errors:
                        raise RuntimeError(f"Recovered integrity errors at {path}: {errors}")
                state=json.loads((root/model/str(month)/"state.json").read_text())
                write_json(root/f"recovery_{model}_{month}.json",{"git_commit":commit,"month":month,
                    "archive":file_record(recovered),"fold_state":state["status"],"verified":True})
                if state["status"]!="complete":
                    raise RuntimeError(f"Remote fold failed: {state.get('error_type')}: {state.get('error')}")
                recovered.unlink()
        finally:
            if created:
                command(["colab","stop","-s",session])


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--model",choices=["tabpfn3","tabfm"],required=True)
    parser.add_argument("--gpu",default="T4")
    parser.add_argument("--session",default="datafest-foundation")
    parser.add_argument("--existing-session",action="store_true",help="Use and release this task's already allocated session")
    args=parser.parse_args()
    run(args.model,args.gpu,args.session,args.existing_session)
