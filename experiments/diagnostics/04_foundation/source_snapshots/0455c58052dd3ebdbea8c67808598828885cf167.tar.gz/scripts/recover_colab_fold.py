"""Recover completed fold files directly, without a memory-sized tar download."""
import argparse
import json
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
from datafest.lineage import sha256_file, verify_manifest_integrity
from colab_stream_download import download


def recover(session,model,month):
    root=Path("experiments/diagnostics/04_foundation")/model
    root.mkdir(parents=True,exist_ok=True)
    parent=root/"manifest.json"
    download(session,"/content/datafest/"+str(parent),str(parent))
    manifest=json.loads(parent.read_text())
    for record in manifest["outputs"]:
        path=Path(record["path"])
        if not path.is_relative_to(root):
            raise ValueError("Unexpected artifact path")
        if path.is_file() and path.stat().st_size==record["bytes"] and sha256_file(path)==record["sha256"]:
            continue
        download(session,"/content/datafest/"+str(path),str(path))
        if sha256_file(path)!=record["sha256"]:
            raise RuntimeError(f"Recovered checksum mismatch: {path}")
    leaf=root/str(month)/"manifest.json"
    download(session,"/content/datafest/"+str(leaf),str(leaf))
    for path in (parent,leaf):
        errors=verify_manifest_integrity(json.loads(path.read_text()))
        if errors: raise RuntimeError(f"Recovered integrity errors: {errors}")
    state=json.loads((root/str(month)/"state.json").read_text())
    if state["status"]!="complete":
        raise RuntimeError(f"Fold was not complete: {state['status']}")
    print(f"Fold {month} recovered and verified",flush=True)


if __name__=="__main__":
    p=argparse.ArgumentParser()
    p.add_argument("--session",required=True)
    p.add_argument("--model",required=True)
    p.add_argument("--month",required=True,type=int)
    a=p.parse_args()
    recover(a.session,a.model,a.month)
